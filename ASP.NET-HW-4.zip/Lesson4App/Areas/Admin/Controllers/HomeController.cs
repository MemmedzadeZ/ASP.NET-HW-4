﻿using Microsoft.AspNetCore.Mvc;

namespace Lesson4App.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
