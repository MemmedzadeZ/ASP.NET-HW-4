using Lesson4App.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Lesson4App.Pages.Product
{
    public class IndexModel : PageModel
    {
        private readonly ProductDbContext _context;

        public IndexModel(ProductDbContext context)
        {
            _context = context;
        }
        public List<Entities.Product> Products { get; set; }
      
        public string Info { get; set; }

        [BindProperty]
        public Entities.Product Product { get; set; }

        public bool isEdit { get; set; } = false;


        public IActionResult OnPost()
        {
            if (Product != null)
            {
                _context.Products.Add(Product);
                _context.SaveChanges();
                Info = $"{Product.Name} added successfully";
                return RedirectToPage("Index", new { info = Info });
            }
            return RedirectToPage("Index", new { info = "Data is null" });
        }
        public void OnGet(string info = "", int id = -1, bool edit = false)
        {
            Products = _context.Products.ToList();
            Info = info;
            if (id != -1)
            {
                Product = _context.Products.SingleOrDefault(p => p.Id == id);

            }
            isEdit = edit;
        }

        public  IActionResult OnGetDelete(int id)
        {
            var product = _context.Products.SingleOrDefault(p => p.Id == id);
            _context.Products.Remove(product);
            _context.SaveChanges();

            return RedirectToPage("Index", new { info = "Product Success DELETE" });

		}

        public IActionResult OnGetGoEdit(int id)
        {
            var product = _context.Products.SingleOrDefault(p => p.Id == id);
            if (product != null)
            {
                return RedirectToPage("Index", new { Id = id, edit = true });
            }
            return RedirectToPage("Index", new { info = "Edit not find " });
        }


        public IActionResult OnPostEdit(int id)
        {
            if (Product != null)
            {
                var product = _context.Products.SingleOrDefault(product => product.Id == id);
                if (product != null)
                {
                    product.Name = Product.Name;
                    product.Price = Product.Price;
                    return RedirectToPage("Index", new { info = "Product edit is successufully" });


                }
                return RedirectToPage("Index", new { info = "Product edit" });
            }
            return RedirectToPage("Index", new { info = "Product edit is successufully" });
        }
    }


}
