﻿namespace Lesson4App.Models
{
    public class CategoryListViewModel
    {
        public IQueryable<CategoryViewModel>? Categories { get; set; }
    }
}
