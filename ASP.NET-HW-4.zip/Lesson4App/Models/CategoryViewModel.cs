﻿namespace Lesson4App.Models
{
    public class CategoryViewModel
    {
        public string? Title { get; set; }
    }
}
